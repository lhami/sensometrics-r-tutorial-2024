## ---------------------------------------------------------------------------------------------------------------------------------------------
getwd() # will print the current working directory


## ---- eval=FALSE------------------------------------------------------------------------------------------------------------------------------
## setwd("Enter/Your/Desired/Directory/Here")


## ---- eval = FALSE----------------------------------------------------------------------------------------------------------------------------
## install.packages("tidytext")


## ---------------------------------------------------------------------------------------------------------------------------------------------
library(tidyverse)


## ---------------------------------------------------------------------------------------------------------------------------------------------
library(tidyverse)
library(tidytext)


## ---------------------------------------------------------------------------------------------------------------------------------------------
sessionInfo()


## ---- eval = FALSE----------------------------------------------------------------------------------------------------------------------------
## ?sessionInfo


## ----example of a code block, eval = FALSE----------------------------------------------------------------------------------------------------
## You can't write this in an R script because it is plain text.  This will
## cause an error.
## 
## # If you want to write text or notes to yourself, use the "#" symbol at the start of
## # every line to "comment" out that line.  You can also put "#" in the middle of
## # a line in order to add a comment - everything after will be ignored.
## 
## 1 + 1 # this is valid R syntax
## 
## print("hello world") # this is also valid R syntax


## ----calculator 1-----------------------------------------------------------------------------------------------------------------------------
2 + 5


## ----calculator 2-----------------------------------------------------------------------------------------------------------------------------
1000 / 3.5


## ----assignment demo--------------------------------------------------------------------------------------------------------------------------
x <- 100
hi <- "hello world"
data_set <- rnorm(n = 100, mean = 0, sd = 1)


## ----algebra 1--------------------------------------------------------------------------------------------------------------------------------
x / 10


## ----algebra 2--------------------------------------------------------------------------------------------------------------------------------
x + 1


## ----updating a variable----------------------------------------------------------------------------------------------------------------------
x
x <- 100 + 1
x


## ----first function---------------------------------------------------------------------------------------------------------------------------
sqrt(x)


## ----a more complex function------------------------------------------------------------------------------------------------------------------
rnorm(n = 100, mean = 0, sd = 1)


## ----argument order matters in functions------------------------------------------------------------------------------------------------------
# This will give us 1 value from the normal distribution with mean = 0 and sd = 100
rnorm(1, 0, 100)

# But we can also use named arguments to provide them in any order we wish!
rnorm(sd = 1, n = 100, mean = 0)


## ----loading packages 1-----------------------------------------------------------------------------------------------------------------------
library(tidyverse)


## ----getting the working directory------------------------------------------------------------------------------------------------------------
getwd()


## ----reading in data--------------------------------------------------------------------------------------------------------------------------
read_csv(file = "data/ba_2002.csv")


## ----storing data when loaded-----------------------------------------------------------------------------------------------------------------
beer_data <- read_csv(file = "data/ba_2002.csv")


## ----object properties 1----------------------------------------------------------------------------------------------------------------------
x <- 100
class(x)
typeof(x)


## ----object properties 2----------------------------------------------------------------------------------------------------------------------
length(x)


## ----the c()ombine function-------------------------------------------------------------------------------------------------------------------
y <- c(1, 2, 3, 10, 50)
y


## ----combining variables with c()-------------------------------------------------------------------------------------------------------------
c(x, y)


## ----vector types-----------------------------------------------------------------------------------------------------------------------------
animals <- c("fox", "bat", "rat", "cat")
class(animals)


## ----type coercion----------------------------------------------------------------------------------------------------------------------------
c(y, animals)


## ----math with characters, error = TRUE-------------------------------------------------------------------------------------------------------
c(y, animals) / 2


## ----examining the str()ucture of objects-----------------------------------------------------------------------------------------------------
str(y)
str(animals)


## ----examining our beer data------------------------------------------------------------------------------------------------------------------
str(beer_data)


## ----subsetting 1-----------------------------------------------------------------------------------------------------------------------------
y[1]
animals[4]


## ----subsetting 2-----------------------------------------------------------------------------------------------------------------------------
animals[c(1, 2)]


## ----the ":" sequence shortcut----------------------------------------------------------------------------------------------------------------
1:3
animals[1:3]


## ----logical operators------------------------------------------------------------------------------------------------------------------------
y < 10


## ----subsetting with logical operators--------------------------------------------------------------------------------------------------------
y[y < 10]


## ----data frame properties--------------------------------------------------------------------------------------------------------------------
nrow(beer_data)
ncol(beer_data)
length(beer_data) # Note that length() of a data.frame is the same as ncol()


## ----examining what a data frame contains, eval = FALSE---------------------------------------------------------------------------------------
## beer_data # simply printing the object
## head(beer_data) # show the first few rows
## tail(beer_data) # show the last few rows
## glimpse(beer_data) # a more compact version of str()
## names(beer_data) # get the variable/column names


## ----subsetting data tables 1-----------------------------------------------------------------------------------------------------------------
beer_data[5, 1] # get the 5th row, 1st column value


## ----subsetting data tables 2-----------------------------------------------------------------------------------------------------------------
beer_data[1:5, 1] # get the first 5 rows of the 1st column value


## ----subsetting data tables 3-----------------------------------------------------------------------------------------------------------------
beer_data[, 2] # get all rows of the 2nd column


## ----logical subsetting for data tables-------------------------------------------------------------------------------------------------------
beer_data[beer_data$rating > 4.5, ] # get all rows for which rating > 3


## ----getting variables out of a data frame, eval = FALSE--------------------------------------------------------------------------------------
## beer_data$style # not printed because it is too long!


## ----reload the beer data in case you started your session over-------------------------------------------------------------------------------
library(tidyverse)
beer_data <- read_csv("data/ba_2002.csv")


## ----use glimpse() to examine the beer data---------------------------------------------------------------------------------------------------
glimpse(beer_data)


## ----reminder of base R subsetting------------------------------------------------------------------------------------------------------------
beer_data[, 9:14]


## ----using select() with explicit column names------------------------------------------------------------------------------------------------
select(beer_data, appearance, aroma, palate, taste, overall, rating) # note the lack of quoting on the column names


## ----using select() with a character search---------------------------------------------------------------------------------------------------
select(beer_data, starts_with("beer"))


## ----combining character search and explicit select()-----------------------------------------------------------------------------------------
select(beer_data, starts_with("beer"), rating, abv)


## ----using where() with select() is more advanced---------------------------------------------------------------------------------------------
select(beer_data, where(~is.numeric(.)))


## ----reminder of how to get rows from a data frame in base R----------------------------------------------------------------------------------
beer_data[1:10, ]


## ----first example of filter() with conditional logic-----------------------------------------------------------------------------------------
filter(beer_data, abv > 10) # let's get some heavy beers


## ----using the equality operator in filter()--------------------------------------------------------------------------------------------------
filter(beer_data, abv > 10, style == "American Barleywine")


## ----using the OR operator in filter()--------------------------------------------------------------------------------------------------------
filter(beer_data, abv > 10, style == "American Barleywine" | style == "English Barleywine")


## ----using character searches in filter()-----------------------------------------------------------------------------------------------------
filter(beer_data, abv > 10, str_detect(style, "Barleywine"))


## ----nesting functions------------------------------------------------------------------------------------------------------------------------
select(filter(beer_data, str_detect(style, "Stout")), contains("beer"), abv, rating)


## ----storing results as intermediates---------------------------------------------------------------------------------------------------------
beer_stouts <- filter(beer_data, str_detect(style, "Stout"))
select(beer_stouts, contains("beer"), abv, rating)


## ----the rm() function deletes objects from the Environment-----------------------------------------------------------------------------------
rm(beer_stouts)


## ----the mighty pipe!-------------------------------------------------------------------------------------------------------------------------
beer_data %>%                              # Start with the beer_data
  filter(str_detect(style, "Stout")) %>%   # AND THEN filter to stouts
  select(contains("beer"), abv, rating)    # AND THEN select the beer columns, etc


## ----order of operations with the pipe--------------------------------------------------------------------------------------------------------
1 + 2 %>% sqrt # this is instead computing 1 + sqrt(2)


## ----parentheses will make the pipe work better-----------------------------------------------------------------------------------------------
(1 + 2) %>% sqrt() # Now this computes sqrt(1 + 2) = sqrt(3)


## ----an example of a custom function----------------------------------------------------------------------------------------------------------
subtract <- function(a, b) a - b
subtract(5, 4)


## ----argument order still matters with piped functions----------------------------------------------------------------------------------------
5 %>% subtract(4)


## ----the pipe will always send the previous step to the first argument of the next step-------------------------------------------------------
4 %>% subtract(5) # this is actually making subtract(4, 5)


## ----using the "." pronoun lets you control order in pipes------------------------------------------------------------------------------------
4 %>% subtract(5, .) # now this properly computes subtract(5, 4)


## ----using pipes with filter()----------------------------------------------------------------------------------------------------------------
beer_data %>%
  filter(rating > 2.5)


## ----first example of mutate()----------------------------------------------------------------------------------------------------------------
beer_data %>%
  mutate(better_than_2.5 = rating > 2.5) %>%
  # We'll select just a few columns to help us see the result
  select(beer_name, rating, better_than_2.5) 


## ----mutate() makes new columns---------------------------------------------------------------------------------------------------------------
# Let's find out the average (mean) rating for these beers
beer_data$rating %>% 
  mean() 

# Now, let's create a column that tells us if a beer is rated > average
beer_data %>%
  mutate(better_than_average = rating > mean(rating)) %>%
  # Again, let's select just a few columns
  select(beer_name, rating, better_than_average)


## ----split-apply-combine pipeline example-----------------------------------------------------------------------------------------------------
beer_summary <- 
  beer_data %>%
  group_by(style) %>%                           # we will create a group for each unique style
  summarize(n_beers = n(),                      # n() counts rows in each style
            mean_rating = mean(rating),         # the mean rating for each style
            sd_rating = sd(rating),             # the standard deviation in rating
            se_rating = sd(rating) / sqrt(n())) # multiple functions in 1 row

beer_summary


## ----simple stat summaries with split-apply-combine-------------------------------------------------------------------------------------------
beer_summary %>%
  mutate(lower_limit = mean_rating - 1.96 * se_rating,
         upper_limit = mean_rating + 1.96 * se_rating)


## ----renaming columns-------------------------------------------------------------------------------------------------------------------------
names(beer_data)

beer_data %>%
  rename(review_text = reviews)


## ----rename() works with positions as well as explicit names----------------------------------------------------------------------------------
beer_data %>%
  rename(review_text = 1)


## ----reordering columns in a tibble-----------------------------------------------------------------------------------------------------------
beer_data %>%
  relocate(beer_name) # giving no other arguments will move to front


## ----using relative positions with relocate()-------------------------------------------------------------------------------------------------
beer_data %>%
  relocate(reviews, .after = rating) # move the long text to the end


## ----arrange() lets you sort your data--------------------------------------------------------------------------------------------------------
beer_data %>%
  arrange(desc(rating)) %>% # what are the highest rated beers?
  select(beer_name, rating)


## ----arrange() works on both numeric and character data---------------------------------------------------------------------------------------
beer_data %>%
  arrange(brewery_name, beer_name) %>% # get beers sorted within breweries
  select(brewery_name, beer_name) %>%  # show only relevant columns
  distinct()                           # discard duplicate rows


## ----pivoting data tables---------------------------------------------------------------------------------------------------------------------
beer_data %>%
  select(beer_name, user_id, appearance:rating) %>% # for clarity
  pivot_longer(cols = appearance:rating,
               names_to = "rating_type",
               values_to = "rating")


## ----non-working schematic of a ggplot, eval = FALSE------------------------------------------------------------------------------------------
## # The ggplot() function creates your plotting environment.  We usually save it to a variable in R so that we can use the plug-n-play functionality of ggplot without retyping a bunch of nonsense
## p <- ggplot(mapping = aes(x = <a variable>, y = <another variable>, ...),
##             data = <your data>)
## 
## # Then, you can add various ways of plotting data to make different visualizations.
## p +
##   geom_<your chosen way of plotting>(...) +
##   theme_<your chosen theme> +
##   ...


## ----a first ggplot---------------------------------------------------------------------------------------------------------------------------
beer_data %>%
  ggplot(mapping = aes(x = rating, y = overall)) + # Here we set up the base plot
  geom_point()                           # Here we tell our base plot to add points


## ----what we are plotting in this example-----------------------------------------------------------------------------------------------------
beer_data %>%
  select(rating, overall)


## ----switching geom_() switches the way the data map------------------------------------------------------------------------------------------
beer_data %>%
  ggplot(mapping = aes(x = rating, y = overall)) + 
  geom_smooth()


## ----geom_()s are layers in a plot------------------------------------------------------------------------------------------------------------
beer_data %>%
  ggplot(mapping = aes(x = rating, y = overall)) + 
  geom_jitter() + # add some random noise to show overlapping points
  geom_smooth()


## ----here are some other parts of the plot we can control with data---------------------------------------------------------------------------
beer_data %>%
  # mutate a new variable for plotting
  mutate(high_abv = ifelse(abv > 9, "yes", "no")) %>%
  drop_na(high_abv) %>%
  ggplot(mapping = aes(x = rating, y = overall, color = high_abv)) +
  geom_jitter(alpha = 1/4) + 
  scale_color_viridis_d() +
  theme_bw()


## ----using the aes() function-----------------------------------------------------------------------------------------------------------------
beer_data %>%
  drop_na(abv) %>%
  ggplot(aes(x = rating, y = overall)) + 
  # We can set new aes() mappings in individual layers, as well as the plot itself
  geom_jitter(aes(alpha = abv)) + 
  theme_bw()


## ----using the theme_*() functions------------------------------------------------------------------------------------------------------------
beer_data %>%
  drop_na() %>%
  ggplot(aes(x = rating, y = overall)) + 
  geom_jitter() + 
  theme_void()


## ----ggplots are R objects--------------------------------------------------------------------------------------------------------------------
p <- 
  beer_data %>%
  # This block gets us a subset of beer styles for clear visualization
  group_by(style) %>%
  nest(data = -style) %>%
  ungroup() %>%
  slice_sample(n = 10) %>%
  unnest(everything()) %>%
  # And now we can go back to plotting
  ggplot(aes(x = rating, group = style)) + 
  # Density plots are smoothed histograms
  geom_density(aes(fill = style), alpha = 1/4, color = NA) +
  theme_bw()

p


## ----we can modify stored plots after the fact------------------------------------------------------------------------------------------------
p + scale_fill_viridis_d()


## ----another example of posthoc plot modification---------------------------------------------------------------------------------------------
# We'll pick 14 random colors from the colors R knows about
random_colors <- print(colors()[sample(x = 1:length(colors()), size = 10)])

p + 
  scale_fill_manual(values = random_colors)


## ----starting with a base plot showing palate tertiles----------------------------------------------------------------------------------------
p <- 
  beer_data %>%
  # Step 1: make abv tertiles
  mutate(abv_tertile = as.factor(ntile(abv, 3))) %>%
  # Step 2: plot
  ggplot(aes(x = palate, group = abv_tertile)) + 
  geom_density(aes(fill = abv_tertile), 
              alpha = 1/4, color = NA, adjust = 3) + 
  theme_classic()

# Unfacetted plot
p


## ----now we split the plot into 3 "small multiples" with facet_wrap()-------------------------------------------------------------------------
p + 
  facet_wrap(~abv_tertile, nrow = 4) +
  theme(legend.position = "none")


## ----making sure that we have loaded all packages and data------------------------------------------------------------------------------------
# The packages we're using
library(tidyverse)
library(tidytext)

# The dataset
beer_data <- read_csv("data/ba_2002.csv")


## ----getting a viewable example---------------------------------------------------------------------------------------------------------------

set.seed(2)

reviews_example <- 
  beer_data %>%
  slice_sample(n = 5)

reviews_example %>%
  select(beer_name, reviews) %>%
  gt::gt()


## ----cleaning our example data----------------------------------------------------------------------------------------------------------------
library(textclean)

cleaned_reviews_example <- 
  reviews_example %>%
  mutate(cleaned_review = reviews %>%
           # Fix some of the HTML placeholders
           replace_html(symbol = FALSE) %>%
           # Replace sequences of "..." 
           replace_incomplete(replacement = " ") %>%
           # Replace less-common or misformatted HTML
           str_replace_all("#.{1,4};", " ") %>%
           # Replace some common non-A-Z, 1-9 symbols
           replace_symbol() %>% 
           # Remove non-word text like ":)"
           replace_emoticon() %>%
           # Remove numbers from the reviews, as they are not useful
           str_remove_all("[0-9]"))

cleaned_reviews_example %>%
  select(beer_name, cleaned_review) %>%
  gt::gt()


## ----cleaning the full data set---------------------------------------------------------------------------------------------------------------
beer_data <- 
  beer_data %>%
  mutate(cleaned_review = reviews %>%
           replace_html(symbol = FALSE) %>%
           replace_incomplete(replacement = " ") %>%
           str_replace_all("#.{1,4};", " ") %>%
           replace_symbol() %>%
           replace_emoticon() %>%
           str_remove_all("[0-9]"))


## ----the numeric part of our data-------------------------------------------------------------------------------------------------------------
cleaned_reviews_example %>% 
  select(beer_name, appearance:rating)


## ----what does text data look like?-----------------------------------------------------------------------------------------------------------
cleaned_reviews_example$cleaned_review[1]


## ----a viewable tokenization example----------------------------------------------------------------------------------------------------------
cleaned_reviews_example$cleaned_review[1] %>%
  tokenizers::tokenize_words(simplify = TRUE)


## ----tokenizing our entire data set into words------------------------------------------------------------------------------------------------
beer_data_tokenized <-
  beer_data %>%
  # We may want to keep track of a unique ID for each review
  mutate(review_id = row_number()) %>%
  unnest_tokens(output = token,
                input = cleaned_review,
                token = "words") %>%
  # Here we do a bit of extra cleaning
  mutate(token = str_remove_all(token, "\\.|_"))

beer_data_tokenized %>%
  # We show just a few of the columns for printing's sake
  select(beer_name, rating, token)


## ----what does tidy tokenized data look like?-------------------------------------------------------------------------------------------------
cleaned_reviews_tokenized <- 
  cleaned_reviews_example %>%
  unnest_tokens(input = cleaned_review, output = token) %>%
  # Here we do a bit of extra cleaning
  mutate(token = str_remove_all(token, "\\.|_"))

cleaned_reviews_tokenized %>%
  filter(beer_name == "Kozel") %>%
  # Let's select a few variables for printing
  select(beer_name, rating, token)


## ----what are the most frequent words in our beer data?---------------------------------------------------------------------------------------
beer_data_tokenized %>%
  # The count() function gives the number of rows that contain unique values
  count(token) %>%
  # get the 20 most frequently occurring words
  slice_max(order_by = n, n = 20) %>%
  # Here we do some wrangling for visualization
  mutate(token = as.factor(token) %>% fct_reorder(n)) %>%
  # let's visualize this just for fun
  ggplot(aes(x = token, y = n)) + 
  geom_col() + 
  coord_flip() + 
  theme_bw() +
  labs(x = NULL, y = NULL, title = "The 20 most frequent words are not that useful.")


## ----stop words look like:--------------------------------------------------------------------------------------------------------------------
stop_words


## ----what are the most frequent NON stop words in beer data?----------------------------------------------------------------------------------
beer_data_tokenized %>%
  # "by = " tells what column to look for in X and Y
  anti_join(y = stop_words, by = c("token" = "word")) %>%
  count(token) %>%
  # get the 20 most frequently occurring words
  slice_max(order_by = n, n = 20) %>%
  # Here we do some wrangling for visualization
  mutate(token = as.factor(token) %>% fct_reorder(n)) %>%
  # let's visualize this just for fun
  ggplot(aes(x = token, y = n)) + 
  geom_col() + 
  coord_flip() + 
  theme_bw() +
  labs(x = NULL, y = NULL, title = "These tokens are much more relevant.", subtitle = "We removed ~1200 stop words.")


## ----what beer styles are in our beer data?---------------------------------------------------------------------------------------------------
beer_data %>%
  count(style)


## ----what words are associated with some basic beer styles?-----------------------------------------------------------------------------------
# First, we'll make sure our approach works
beer_data %>%
  # First we will set our style to lower case to make matching easier
  mutate(style = tolower(style),
         # Then we will use a conditional match to create our new style
         simple_style = case_when(str_detect(style, "lager") ~ "lager",
                                  str_detect(style, "ipa") ~ "IPA",
                                  str_detect(style, "stout|porter") ~ "dark",
                                  TRUE ~ "other")) %>%
  count(simple_style)

# Then we'll implement the approach for our tokenized data
beer_data_tokenized <- 
  beer_data_tokenized %>%
  mutate(style = tolower(style),
         # Then we will use a conditional match to create our new style
         simple_style = case_when(str_detect(style, "lager") ~ "lager",
                                  str_detect(style, "ipa") ~ "IPA",
                                  str_detect(style, "stout|porter") ~ "dark",
                                  TRUE ~ "other")) 

# Finally, we'll plot the most frequent terms for each simple_style
beer_data_tokenized %>%
  # filter out stop words
  anti_join(stop_words, by = c("token" = "word")) %>%
  # This time we count tokens WITHIN simple_style
  count(simple_style, token) %>%
  # Then we will group_by the simple_style
  group_by(simple_style) %>%
  slice_max(order_by = n, n = 20) %>%
  # Removing the group_by is necessary for some steps
  ungroup() %>%
  # A bit of wrangling for plotting
  mutate(token = as.factor(token) %>% reorder_within(by = n, within = simple_style)) %>%
  ggplot(aes(x = token, y = n, fill = simple_style)) +
  geom_col(show.legend = FALSE) + 
  facet_wrap(~simple_style, scales = "free", ncol = 4) + 
  scale_x_reordered() + 
  theme_bw() + 
  coord_flip() +
  labs(x = NULL, y = NULL, title = "Different (sensory) words tend to be used with different styles.") +
  theme(axis.text.x = element_text(angle = 90))


## ----tf-idf example---------------------------------------------------------------------------------------------------------------------------
# Let's first experiment with our "simple_styles"
beer_styles_tf_idf <-
  beer_data_tokenized %>%
  count(simple_style, token) %>%
  # And now we can directly add on tf-idf
  bind_tf_idf(term = token, document = simple_style, n = n)

beer_styles_tf_idf %>%
  # let's look at some stop words
  filter(token %in% c("is", "a", "the", "beer")) %>%
  gt::gt()


## ----what words are most important for our simple styles by tf-idf?---------------------------------------------------------------------------
beer_styles_tf_idf %>%
  # We still group by simple_style
  group_by(simple_style) %>%
  # Now we want tf-idf, not raw count
  slice_max(order_by = tf_idf, n = 20) %>%
  ungroup() %>%
  # A bit of wrangling for plotting
  mutate(token = as.factor(token) %>% reorder_within(by = tf_idf, within = simple_style)) %>%
  ggplot(aes(x = token, y = tf_idf, fill = simple_style)) +
  geom_col(show.legend = FALSE) + 
  facet_wrap(~simple_style, scales = "free", ncol = 4) + 
  scale_x_reordered() + 
  theme_bw() + 
  coord_flip() +
  labs(x = NULL,
       y = NULL, 
       title = "With tf-idf we get much more specific terms.", 
       subtitle = "For example, 'oatmeal' for stouts, 'grapefruity' for IPAs, and so on.") +
  theme(axis.text.x = element_blank())


## ----what words are associated with very good or bad beers by tf-idf?-------------------------------------------------------------------------
beer_data_tokenized %>%
  # First we get deciles of rating
  mutate(rating_decile = ntile(rating, n = 10)) %>%
  # And we'll select just the top 2 and bottom 2 deciles %>%
  filter(rating_decile %in% c(1, 2, 9, 10)) %>%
  # Then we follow the exact same pipeline to get tf-idf
  count(rating_decile, token) %>%
  bind_tf_idf(term = token, document = rating_decile, n = n) %>%
  group_by(rating_decile) %>%
  # Since we have more groups, we'll just look at 10 tokens
  slice_max(order_by = tf_idf, n = 10) %>%
  ungroup() %>%
  # A bit of wrangling for plotting
  mutate(token = as.factor(token) %>% reorder_within(by = tf_idf, within = rating_decile)) %>%
  ggplot(aes(x = token, y = tf_idf, fill = rating_decile)) +
  geom_col(show.legend = FALSE) + 
  facet_wrap(~rating_decile, scales = "free", ncol = 4) + 
  scale_x_reordered() + 
  scale_fill_viridis_c() +
  theme_bw() + 
  coord_flip() +
  labs(x = NULL,
       y = NULL, 
       subtitle = "When we compare the top 2 and bottom 2 deciles, we see much more affective language.") +
  theme(axis.text.x = element_blank())



## ----tf-idf is data-based so it will change with "document" choice, echo = FALSE--------------------------------------------------------------
beer_data_tokenized %>%
  # First we get deciles of rating
  mutate(rating_decile = ntile(rating, n = 10)) %>%
  # Then we follow the exact same pipeline to get tf-idf
  count(rating_decile, token) %>%
  bind_tf_idf(term = token, document = rating_decile, n = n) %>%
  group_by(rating_decile) %>%
  # Since we have more groups, we'll just look at 10 tokens
  slice_max(order_by = tf_idf, n = 10) %>%
  ungroup() %>%
  # A bit of wrangling for plotting
  mutate(token = as.factor(token) %>% reorder_within(by = tf_idf, within = rating_decile)) %>%
  ggplot(aes(x = token, y = tf_idf, fill = rating_decile)) +
  geom_col(show.legend = FALSE) + 
  facet_wrap(~rating_decile, scales = "free", ncol = 5) + 
  scale_x_reordered() + 
  scale_fill_viridis_c() +
  theme_bw() + 
  coord_flip() +
  labs(x = NULL,
       y = NULL, 
       title = "tf-idf will change based on the documents being compared") +
  theme(axis.text.x = element_blank())


## ----the included lexicons for sentiment in tidytext------------------------------------------------------------------------------------------
sentiments

count(sentiments, sentiment)


## ----using simple data wrangling to add sentiments to our beer data---------------------------------------------------------------------------
beer_sentiments <- 
  beer_data_tokenized %>%
  left_join(sentiments, by = c("token" = "word"))

beer_sentiments %>%
  select(review_id, beer_name, style, rating, token, sentiment)


## ----our split-apply-combine approach for sentiment analysis----------------------------------------------------------------------------------
sentiment_ratings <- 
  beer_sentiments %>%
  count(review_id, sentiment) %>%
  drop_na() %>%
  group_by(review_id) %>%
  pivot_wider(names_from = sentiment, values_from = n, values_fill = 0) %>%
  mutate(sentiment = positive - negative)

sentiment_ratings


## ----visualizing basic sentiment against rating, warning = FALSE, message = FALSE-------------------------------------------------------------
beer_data %>%
  mutate(review_id = row_number()) %>%
  left_join(sentiment_ratings) %>%
  ggplot(aes(x = sentiment, y = rating)) + 
  geom_jitter(alpha = 0.2, size = 1) + 
  geom_smooth(method = "lm") +
  coord_cartesian(xlim = c(-11, 30), ylim = c(1, 5)) +
  theme_bw()


## ----we can improve by doing some normalization-----------------------------------------------------------------------------------------------
beer_data <- 
  beer_data %>%
  mutate(review_id = row_number()) %>%
  left_join(sentiment_ratings)

beer_data %>%
  select(beer_name, style, rating, sentiment) %>%
  pivot_longer(cols = c(rating, sentiment), names_to = "scale", values_to = "value") %>%
  group_by(style, scale) %>%
  summarize(mean_value = mean(value, na.rm = TRUE),
            se_value = sd(value, na.rm = TRUE) / sqrt(n())) %>%
  group_by(scale) %>%
  slice_max(order_by = mean_value, n = 10) %>%
  ungroup() %>%
  mutate(style = factor(style) %>% reorder_within(by = mean_value, within = scale)) %>%
  ggplot(aes(x = style, y = mean_value, fill = scale)) + 
  geom_col(position = "dodge", show.legend = FALSE) + 
  scale_x_reordered() +
  coord_flip() +
  facet_wrap(~scale, scales = "free")


## ----where are the disagreements between rating and sentiment?--------------------------------------------------------------------------------
# Here are the reviews where the ratings most disagree with the sentiment
beer_data %>%
  # normalize sentiment and ratings so we can find the largest mismatch
  mutate(rating_norm = rating / max(rating, na.rm = TRUE),
         sentiment_norm = sentiment / max(sentiment, na.rm = TRUE),
         diff = rating_norm - sentiment_norm) %>%
  select(review_id, beer_name, sentiment_norm, rating_norm, diff, cleaned_review) %>%
  slice_max(order_by = diff, n = 2) %>%
  gt::gt()

# And here are the reviews where the sentiment most disagreed with the rating
beer_data %>%
  # normalize sentiment and ratings so we can find the largest mismatch
  mutate(rating_norm = rating / max(rating, na.rm = TRUE),
         sentiment_norm = sentiment / max(sentiment, na.rm = TRUE),
         diff = sentiment_norm - rating_norm) %>%
  select(review_id, beer_name, sentiment_norm, rating_norm, diff, cleaned_review) %>%
  slice_max(order_by = diff, n = 2) %>%
  gt::gt()


## ----review length seems to affect rating and sentiment to different degrees, message = FALSE, warning = FALSE--------------------------------
beer_data %>%
  mutate(word_count = tokenizers::count_words(cleaned_review)) %>%
  select(review_id, rating, sentiment, word_count) %>%
  pivot_longer(cols = c(rating, sentiment)) %>%
  ggplot(aes(x = word_count, y = value, color = name)) + 
  geom_jitter() + 
  geom_smooth(method = "lm", color = "black") + 
  facet_wrap(~name, scales = "free") +
  theme_bw() + 
  theme(legend.position = "none")


## ----tokenizing for bigrams-------------------------------------------------------------------------------------------------------------------
beer_bigrams <- 
  beer_data %>%
  unnest_tokens(output = bigram, input = cleaned_review, token = "ngrams", n = 2)

beer_bigrams %>%
  filter(review_id == 1) %>%
  select(beer_name, bigram)


## ----what are the most common bigrams with "not"?---------------------------------------------------------------------------------------------
beer_bigrams %>%
  separate(col = bigram, into = c("word1", "word2"), sep = " ") %>%
  # Now we will first filter for bigrams starting with "not"
  filter(word1 == "not") %>%
  # And then we'll count up the most frequent pairs of negated biterms
  count(word1, word2) %>%
  arrange(-n)


## ----what are our most important SENTIMENT bigrams with "not"?--------------------------------------------------------------------------------
beer_bigrams %>%
  separate(col = bigram, into = c("word1", "word2"), sep = " ") %>%
  filter(word1 == "not") %>%
  inner_join(sentiments, by = c("word2" = "word")) %>%
  count(word1, word2, sort = TRUE)


## ----more sophisticated lexicon-based sentiment analysis with sentimentr----------------------------------------------------------------------
library(sentimentr)

polarity_sentiment <- 
  cleaned_reviews_example %>% 
  select(beer_name, rating, cleaned_review) %>%
  get_sentences() %>%
  sentiment_by(by = "beer_name")

polarity_sentiment

