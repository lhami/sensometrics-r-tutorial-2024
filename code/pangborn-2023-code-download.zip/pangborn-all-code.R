## ----setup-----------------------------------------------------------------------------------
library(tidyverse)
library(ca)
library(ggrepel)
berry_data <- read_csv("data/clt-berry-data.csv")



